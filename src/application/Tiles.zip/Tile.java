package application;


public abstract class Tile {
	protected String imageFileName;
	
	protected Tile(){
	}
	

	public abstract String getImageFileName();
	
	
}
