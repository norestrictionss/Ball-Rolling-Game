package application;

public interface Movable {
	public void setLocation(int location);
}
