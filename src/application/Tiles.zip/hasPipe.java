package application;

public interface hasPipe {
	public int getPipeDirection();
}
